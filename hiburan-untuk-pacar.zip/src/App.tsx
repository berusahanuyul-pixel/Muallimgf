import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart, Sparkles, Trophy, Ticket, Bot, Calendar, Settings,
  Home, Plus, Trash2, HeartHandshake, Smile, X, HeartOff, Check, Edit
} from 'lucide-react';
import { SweetConfig, LoveCoupon, MemoryItem, ActiveTab } from './types';

// Importing our custom components
import FallingHeartsGame from './components/FallingHeartsGame';
import LoveWheel from './components/LoveWheel';
import CompanionChat from './components/CompanionChat';
import MemoryTimeline from './components/MemoryTimeline';

// Default mock configuration data for Indonesian lovers
const DEFAULT_CONFIG: SweetConfig = {
  boyfriendName: "Ayang Ganteng",
  girlfriendName: "Cantiik",
  anniversaryDate: "2024-10-12", // 12 October 2024
  mainLoveLetter: "Halo manisku sayang... Website ini sengaja aku buat khusus untuk menemani hari-harimu kalau aku lagi gak ada di sampingmu. Semoga tiap fitur di sini bisa bikin kamu tersenyum ya! Love you so much! ❤️",
  coupons: [
    { id: "c1", title: "Free Jajan Boba 🧋", description: "Bebas klaim kapanpun kamu mau boba dingin segar dan jajan crepes manis. Aku yang bayar!", emoji: "🧋", redeemed: false, costPoints: 50 },
    { id: "c2", title: "Pelukan Hangat 10 Menit 🥺", description: "Klaim pelukan terhangat dan termanis dari pacarmu saat ketemu, lengkap dengan puk-puk kepala.", emoji: "🤗", redeemed: false, costPoints: 80 },
    { id: "c3", title: "Diturutin 1 Permintaan! 👑", description: "Aku bakal nurutin satu permintaan bebas kamu tanpa bantah sedikitpun seharian penuh. Pikir baik-baik ya!", emoji: "💖", redeemed: false, costPoints: 150 },
    { id: "c4", title: "Pijat Pegal-Pegal Professional  💆‍♀️", description: "Capek setelah seharian beraktivitas? Klaim sesi pijat punggung dan kaki santai oleh pelayan pribadimu ini.", emoji: "💆‍♀️", redeemed: false, costPoints: 120 },
    { id: "c5", title: "Kencan Premium Pilihanmu 🎬🍿", description: "Klaim tiket kencan impianmu! Nonton bioskop terupdate, makan makanan enak kesukaanmu, dan jalan-jalan seru.", emoji: "🍿", redeemed: false, costPoints: 200 }
  ],
  memories: [
    { id: "m1", date: "2024-10-12", title: "Hari Jadian Kita! 💍", description: "Hari terindah di mana kita resmi berkomitmen bersama untuk saling menyayangi dan melengkapi. Gak kerasa ya sayang waktu berjalan cepat!", emoji: "💖" },
    { id: "m2", date: "2024-11-20", title: "Kencan Pertama Menonton Bioskop 🍿", description: "Pertama kali duduk bersebelahan di bioskop, pengen pegangan tangan tapi malu-malu dan tangan kita sama-sama dingin kaku haha!", emoji: "🎬" },
    { id: "m3", date: "2025-01-01", title: "Merayakan Tahun Baru Bersama 🎇", description: "Melihat kembang api bersama sambil berbisik tentang impian masa depan kita berdua. Semoga tahun-tahun berikutnya tetap bersamamu.", emoji: "✨" }
  ]
};

interface HeartParticle {
  id: number;
  x: number;
  y: number;
  size: number;
  delay: number;
}

export default function App() {
  const [config, setConfig] = useState<SweetConfig>(DEFAULT_CONFIG);
  const [points, setPoints] = useState<number>(100); // starts with some love coins
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [showHeartShowers, setShowHeartShowers] = useState<HeartParticle[]>([]);
  
  // Custom states for the customization editor form
  const [editBoyfriend, setEditBoyfriend] = useState('');
  const [editGirlfriend, setEditGirlfriend] = useState('');
  const [editDate, setEditDate] = useState('');
  const [editLetter, setEditLetter] = useState('');
  
  // States for adding memory
  const [newMemDate, setNewMemDate] = useState('');
  const [newMemTitle, setNewMemTitle] = useState('');
  const [newMemDesc, setNewMemDesc] = useState('');
  const [newMemEmoji, setNewMemEmoji] = useState('💕');

  // Breathing Helper state
  const [isBreathingState, setIsBreathingState] = useState<'idle' | 'inhale' | 'hold' | 'exhale'>('idle');
  const [breathCounter, setBreathCounter] = useState(4);

  // Load configuration from localStorage on mount
  useEffect(() => {
    const savedConfig = localStorage.getItem('sweet_app_config');
    const savedPoints = localStorage.getItem('sweet_app_points');
    
    if (savedConfig) {
      try {
        setConfig(JSON.parse(savedConfig));
      } catch (e) {
        console.error("Failed loading configuration", e);
      }
    }
    if (savedPoints) {
      setPoints(parseInt(savedPoints) || 0);
    }
  }, []);

  // Save changes helper
  const saveConfigToStorage = (newConfig: SweetConfig) => {
    setConfig(newConfig);
    localStorage.setItem('sweet_app_config', JSON.stringify(newConfig));
  };

  const handleEarnPoints = (earned: number) => {
    const updatedPoints = points + earned;
    setPoints(updatedPoints);
    localStorage.setItem('sweet_app_points', updatedPoints.toString());
    triggerHeartsShower();
  };

  const handleRedeemCoupon = (couponId: string, costPoints: number) => {
    if (points >= costPoints) {
      const updatedCoupons = config.coupons.map(c => 
        c.id === couponId ? { ...c, redeemed: true } : c
      );
      const updatedConfig = { ...config, coupons: updatedCoupons };
      saveConfigToStorage(updatedConfig);
      
      const remainingPoints = points - costPoints;
      setPoints(remainingPoints);
      localStorage.setItem('sweet_app_points', remainingPoints.toString());
      triggerHeartsShower();
    }
  };

  // Hearts particle shower trigger
  const triggerHeartsShower = () => {
    const newHearts = Array.from({ length: 25 }).map((_, i) => ({
      id: Date.now() + i,
      x: 10 + Math.random() * 80, // percentage x-axis
      y: 100, // starts at bottom
      size: 15 + Math.random() * 25,
      delay: Math.random() * 1.5,
    }));
    setShowHeartShowers(newHearts);
    setTimeout(() => {
      setShowHeartShowers([]);
    }, 4000);
  };

  // Breathing exercise automatic cycle
  useEffect(() => {
    if (selectedMood !== 'CAPEK') {
      setIsBreathingState('idle');
      return;
    }

    let interval: NodeJS.Timeout;
    
    const runBreathingCycle = () => {
      setIsBreathingState('inhale');
      setBreathCounter(4);
      
      let count = 4;
      interval = setInterval(() => {
        count--;
        setBreathCounter(count);
        
        if (count === 0) {
          clearInterval(interval);
          
          // Switch to HOLD state
          setIsBreathingState('hold');
          setBreathCounter(4);
          let holdCount = 4;
          interval = setInterval(() => {
            holdCount--;
            setBreathCounter(holdCount);
            
            if (holdCount === 0) {
              clearInterval(interval);
              
              // Switch to EXHALE state
              setIsBreathingState('exhale');
              setBreathCounter(4);
              let exhaleCount = 4;
              interval = setInterval(() => {
                exhaleCount--;
                setBreathCounter(exhaleCount);
                
                if (exhaleCount === 0) {
                  clearInterval(interval);
                  // restart cycle
                  runBreathingCycle();
                }
              }, 1000);
            }
          }, 1000);
        }
      }, 1000);
    };

    runBreathingCycle();

    return () => {
      clearInterval(interval);
    };
  }, [selectedMood]);

  // Setup form fields when entering editing tab
  useEffect(() => {
    if (activeTab === 'edit') {
      setEditBoyfriend(config.boyfriendName);
      setEditGirlfriend(config.girlfriendName);
      setEditDate(config.anniversaryDate);
      setEditLetter(config.mainLoveLetter);
    }
  }, [activeTab]);

  const handleUpdateConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = {
      ...config,
      boyfriendName: editBoyfriend || config.boyfriendName,
      girlfriendName: editGirlfriend || config.girlfriendName,
      anniversaryDate: editDate || config.anniversaryDate,
      mainLoveLetter: editLetter || config.mainLoveLetter
    };
    saveConfigToStorage(updated);
    setActiveTab('home');
    triggerHeartsShower();
  };

  const handleAddMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemDate || !newMemTitle || !newMemDesc) return;
    
    const newMemory: MemoryItem = {
      id: 'mem_' + Date.now(),
      date: newMemDate,
      title: newMemTitle,
      description: newMemDesc,
      emoji: newMemEmoji
    };

    const updated = {
      ...config,
      memories: [...config.memories, newMemory]
    };

    saveConfigToStorage(updated);
    setNewMemDate('');
    setNewMemTitle('');
    setNewMemDesc('');
    setNewMemEmoji('💕');
    triggerHeartsShower();
  };

  const handleDeleteMemory = (id: string) => {
    const updatedMemories = config.memories.filter(m => m.id !== id);
    const updated = { ...config, memories: updatedMemories };
    saveConfigToStorage(updated);
  };

  // Reset entirely to initial settings helper
  const handleResetApp = () => {
    if (window.confirm("Beneran mau reset semua kustomisasi data cinta ke awal sayang? ❤️")) {
      setConfig(DEFAULT_CONFIG);
      setPoints(100);
      localStorage.setItem('sweet_app_config', JSON.stringify(DEFAULT_CONFIG));
      localStorage.setItem('sweet_app_points', '100');
      setActiveTab('home');
      triggerHeartsShower();
    }
  };

  return (
    <div className="min-h-screen w-full relative overflow-x-hidden font-sans bg-[#f8fafc] text-slate-800 pb-20 pt-4 px-4 md:px-0 flex flex-col items-center">
      
      {/* BACKGROUND MESH GRADIENTS (FROSTED GLASS THEME REQUIREMENT) */}
      <div className="absolute top-[-100px] left-[-100px] w-[500px] h-[500px] bg-pink-200 rounded-full blur-[110px] opacity-60 pointer-events-none z-0"></div>
      <div className="absolute bottom-[-150px] right-[-100px] w-[600px] h-[600px] bg-indigo-200 rounded-full blur-[130px] opacity-50 pointer-events-none z-0"></div>
      <div className="absolute top-[250px] right-[100px] w-[350px] h-[350px] bg-rose-300 rounded-full blur-[100px] opacity-40 pointer-events-none z-0"></div>
      <div className="absolute bottom-[200px] left-[5%] w-[300px] h-[300px] bg-sky-200 rounded-full blur-[100px] opacity-40 pointer-events-none z-0"></div>

      {/* FLOATING DECORATIONS */}
      <div className="absolute top-10 left-12 w-6 h-6 bg-pink-400/20 rounded-lg rotate-12 backdrop-blur-md pointer-events-none animate-float-slow hidden md:block"></div>
      <div className="absolute bottom-20 right-14 w-10 h-10 bg-indigo-400/20 rounded-full backdrop-blur-md pointer-events-none animate-pulse-slow hidden md:block"></div>
      
      {/* SHOWER HEART PARTICLES */}
      <AnimatePresence>
        {showHeartShowers.map((heart) => (
          <motion.div
            key={heart.id}
            initial={{ opacity: 0.9, y: '100vh', x: `${heart.x}vw`, scale: 0.6 }}
            animate={{ 
              opacity: [0.9, 0.8, 0], 
              y: '-10vh', 
              x: `${heart.x + (Math.random() * 15 - 7.5)}vw`,
              rotate: [0, 180, 360]
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 3.5, delay: heart.delay, ease: "easeOut" }}
            className="fixed pointer-events-none z-50 text-rose-500 fill-rose-500 drop-shadow-md"
            style={{ fontSize: `${heart.size}px` }}
          >
            ❤️
          </motion.div>
        ))}
      </AnimatePresence>

      {/* TOP BAR / INFORMATION HUB */}
      <header className="z-10 w-full max-w-4xl bg-white/40 backdrop-blur-[24px] border border-white/60 shadow-[0_8px_32px_0_rgba(15,23,42,0.06)] rounded-3xl p-4 mb-6 flex flex-wrap justify-between items-center gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 bg-rose-100 rounded-2xl flex items-center justify-center border border-white shadow-inner animate-pulse-slow">
            <Heart className="fill-rose-500 text-rose-500" size={20} />
          </div>
          <div>
            <h1 className="font-serif font-extrabold text-sm text-slate-900 tracking-tight leading-none mb-1">
              {config.boyfriendName} ❤️ {config.girlfriendName}
            </h1>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
              Anak Manis Harus Bahagia ✨
            </p>
          </div>
        </div>

        {/* Savings Balance */}
        <div className="flex items-center gap-2">
          <div className="bg-white/70 backdrop-blur-sm border border-white/80 px-3.5 py-1.5 rounded-full flex items-center gap-2 text-rose-600 font-extrabold text-xs shadow-xs">
            <Trophy size={14} className="text-pink-500" />
            <span>{points} Poin Cinta</span>
          </div>
          <button
            onClick={() => setActiveTab('edit')}
            className={`p-1.5 rounded-xl border transition-all ${
              activeTab === 'edit'
                ? 'bg-rose-500 text-white border-rose-500'
                : 'bg-white/60 border-white/80 text-slate-600 hover:bg-rose-50'
            }`}
            title="Pengaturan Data Cinta"
          >
            <Settings size={16} />
          </button>
        </div>
      </header>

      {/* MAIN LAYOUT CANVAS */}
      <main className="z-10 w-full max-w-4xl flex-1 flex flex-col items-center">
        <AnimatePresence mode="wait">
          
          {/* TAB 1: HOME PANEL */}
          {activeTab === 'home' && (
            <motion.div
              key="tab-home"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="w-full flex flex-col items-center"
            >
              
              {/* Core Frosted Glass Greeting Card */}
              <div className="w-full bg-white/40 backdrop-blur-[32px] border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] rounded-[40px] p-6 md:p-10 flex flex-col items-center text-center">
                
                {/* Couple Photo Section with Face Scribbles */}
                <div className="w-48 h-48 mb-6 mx-auto relative rounded-full overflow-hidden border-4 border-white/80 shadow-md bg-white/50 backdrop-blur-sm group">
                  <img 
                    src="/foto-kita.jpg" 
                    alt="Foto Berdua Kita" 
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1543852786-1cf6624b9987?auto=format&fit=crop&q=80&w=300&h=300"; // fallback cute couple cats
                    }}
                  />
                  {/* Face Coretan Overlay */}
                  <div className="absolute inset-0 pointer-events-none">
                    {/* Coretan for the left face (Boy) */}
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.5 }}
                      animate={{ opacity: 0.85, scale: 1 }}
                      transition={{ delay: 0.5, type: 'spring' }}
                      className="absolute top-[40%] left-[38%] -translate-x-1/2 -translate-y-1/2 w-14 h-14 text-slate-800"
                    >
                      <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
                        <path d="M10 20 Q 50 60, 20 80 T 80 90 T 50 10 T 90 30" stroke="currentColor" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />
                        <path d="M15 15 L 85 85 M 85 15 L 15 85" stroke="currentColor" strokeWidth="10" strokeLinecap="round" />
                      </svg>
                    </motion.div>
                    
                    {/* Coretan for the right face (Girl) */}
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.5 }}
                      animate={{ opacity: 0.85, scale: 1 }}
                      transition={{ delay: 0.7, type: 'spring' }}
                      className="absolute top-[70%] left-[78%] -translate-x-1/2 -translate-y-1/2 w-12 h-12 text-rose-500"
                    >
                      <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
                        <path d="M20 15 C 50 50, 10 70, 40 90 S 90 70, 70 20 S 20 10, 80 80" stroke="currentColor" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />
                        <path d="M20 20 L 80 80 M 80 20 L 20 80" stroke="currentColor" strokeWidth="10" strokeLinecap="round" />
                      </svg>
                    </motion.div>
                  </div>
                </div>

                {/* Question Segment */}
                <h2 className="text-3xl md:text-4xl font-serif font-extrabold text-slate-900 tracking-tight mb-2">
                  Lagi apa {config.girlfriendName} sayang? ✨
                </h2>
                
                <p className="text-xs md:text-sm text-slate-500 font-bold tracking-widest uppercase mb-4">
                  DIKIRIM SPESIAL OLEH PACARMU 💖
                </p>

                <p className="max-w-md text-sm md:text-base text-slate-600 leading-relaxed font-medium mb-8 italic">
                  "{config.mainLoveLetter}"
                </p>

                {/* Interactive Mood Selectors */}
                <div className="w-full text-left mb-8">
                  <label className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block mb-3 text-center">
                    Klik kondisi aslimu sekarang biar aku hibur:
                  </label>
                  
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                    <button
                      onClick={() => { setSelectedMood('KANGEN'); triggerHeartsShower(); }}
                      className={`p-3.5 rounded-2xl border text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-1.5 cursor-pointer transform hover:scale-102 active:scale-98 ${
                        selectedMood === 'KANGEN' 
                          ? 'bg-rose-500 text-white border-rose-500' 
                          : 'bg-white/60 hover:bg-rose-50 text-slate-700 border-white/60'
                      }`}
                    >
                      <span className="text-xl">🥺</span>
                      <span>Kangen Kamu</span>
                    </button>

                    <button
                      onClick={() => { setSelectedMood('CAPEK'); }}
                      className={`p-3.5 rounded-2xl border text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-1.5 cursor-pointer transform hover:scale-102 active:scale-98 ${
                        selectedMood === 'CAPEK' 
                          ? 'bg-sky-500 text-white border-sky-500 animate-pulse-slow' 
                          : 'bg-white/60 hover:bg-sky-50 text-slate-700 border-white/60'
                      }`}
                    >
                      <span className="text-xl">😭</span>
                      <span>Lelah / Sedih</span>
                    </button>

                    <button
                      onClick={() => { setSelectedMood('GABUT'); }}
                      className={`p-3.5 rounded-2xl border text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-1.5 cursor-pointer transform hover:scale-102 active:scale-98 ${
                        selectedMood === 'GABUT' 
                          ? 'bg-amber-500 text-white border-amber-500' 
                          : 'bg-white/60 hover:bg-amber-50 text-slate-700 border-white/60'
                      }`}
                    >
                      <span className="text-xl">🥱</span>
                      <span>Gabut / Bosen</span>
                    </button>

                    <button
                      onClick={() => { setSelectedMood('KENYANG'); }}
                      className={`p-3.5 rounded-2xl border text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-1.5 cursor-pointer transform hover:scale-102 active:scale-98 ${
                        selectedMood === 'KENYANG' 
                          ? 'bg-emerald-500 text-white border-emerald-500' 
                          : 'bg-white/60 hover:bg-emerald-50 text-slate-700 border-white/60'
                      }`}
                    >
                      <span className="text-xl">🍱</span>
                      <span>Sudah Makan</span>
                    </button>

                    <button
                      onClick={() => { setSelectedMood('SEBEL'); }}
                      className={`p-3.5 rounded-2xl border text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-1.5 cursor-pointer transform hover:scale-102 active:scale-98 col-span-2 md:col-span-1 ${
                        selectedMood === 'SEBEL' 
                          ? 'bg-indigo-500 text-white border-indigo-500' 
                          : 'bg-white/60 hover:bg-indigo-50 text-slate-700 border-white/60'
                      }`}
                    >
                      <span className="text-xl">😤</span>
                      <span>Lagi Marah/Sebel</span>
                    </button>
                  </div>
                </div>

                {/* Interactive Mood Feedback Screen */}
                <AnimatePresence mode="wait">
                  {selectedMood && (
                    <motion.div
                      key={selectedMood}
                      initial={{ opacity: 0, scale: 0.95, y: 10 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95, y: -10 }}
                      className="w-full bg-white/80 border border-pink-150/40 rounded-3xl p-5 md:p-6 shadow-inner text-left relative overflow-hidden mb-6"
                    >
                      {/* Close feedback */}
                      <button
                        onClick={() => setSelectedMood(null)}
                        className="absolute top-3.5 right-3.5 p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-all"
                      >
                        <X size={16} />
                      </button>

                      {selectedMood === 'KANGEN' && (
                        <div>
                          <div className="flex items-center gap-2 text-rose-500 mb-2 font-bold font-serif">
                            <Heart className="fill-rose-500 animate-bounce" size={18} />
                            <span>Aduhh, hatiku ikutan bergetar! 💓</span>
                          </div>
                          <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                            Aku juga kangen bangeeeet sama kamu sayang! 🥺 Gak sabar pengen langsung ketemu dan nyubit pipi gembulmu itu. Sementara kita jauh, nih aku kirim sejuta pelukan roket virtual dan ciuman hangat terbang khusus buat kamu. Muachhh! 😘💨💖
                          </p>
                          <button
                            onClick={triggerHeartsShower}
                            className="mt-3.5 px-4 py-2 bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white font-bold text-xs rounded-xl shadow-md transition-all transform active:scale-95 flex items-center gap-1.5"
                          >
                            <Heart className="fill-white" size={14} /> Kirim Kangen Balik ❤️
                          </button>
                        </div>
                      )}

                      {selectedMood === 'CAPEK' && (
                        <div className="flex flex-col md:flex-row gap-5 items-center">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 text-sky-500 mb-2 font-bold font-serif animate-pulse">
                              <Smile size={18} />
                              <span>Sini bersandar di bahuku sayang... 🧸</span>
                            </div>
                            <p className="text-xs md:text-sm text-slate-600 leading-relaxed mb-3">
                              Cup cup cup, kasihan kesayanganku lelah ya? Kamu udah berusaha luar biasa hari ini, aku bangga banget sama kamu. Sekarang rileks sejenak yuk. Ikuti balon bernafas di samping untuk menenangkan pikiranmu luar dalam:
                            </p>
                            <div className="text-[10px] font-bold text-sky-600 bg-sky-50 py-1.5 px-3 rounded-full inline-block">
                              Status Nafas: <span className="uppercase font-extrabold">{isBreathingState}</span> ({breathCounter}s)
                            </div>
                          </div>
                          
                          {/* Animated Breath Bubble */}
                          <div className="w-32 h-32 flex items-center justify-center relative bg-sky-50 rounded-full shrink-0 border border-sky-100 shadow-inner">
                            <motion.div
                              animate={{
                                scale: isBreathingState === 'inhale' ? 1.4 : isBreathingState === 'hold' ? 1.4 : 1.0,
                                backgroundColor: isBreathingState === 'inhale' ? '#93c5fd' : isBreathingState === 'hold' ? '#60a5fa' : '#c084fc'
                              }}
                              transition={{ duration: 4, ease: "easeInOut" }}
                              className="w-16 h-16 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-md"
                            >
                              {isBreathingState === 'inhale' && "Tarik 😤"}
                              {isBreathingState === 'hold' && "Tahan 🤫"}
                              {isBreathingState === 'exhale' && "Buang 💨"}
                            </motion.div>
                          </div>
                        </div>
                      )}

                      {selectedMood === 'GABUT' && (
                        <div>
                          <div className="flex items-center gap-2 text-amber-500 mb-2 font-bold font-serif">
                            <Sparkles size={18} className="animate-spin" />
                            <span>Bosen Melanda? Kita gempur! 🏹</span>
                          </div>
                          <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                            Lagi bosen atau gabut ya cantik? Jangan melamun sendirian dong! Kita main game tangkap cinta aja yuk! Selain seru, kamu bisa dapet banyak koin cinta buat dituker kupon hadiah real life lho. Menarik kan? 🥰
                          </p>
                          <button
                            onClick={() => setActiveTab('game')}
                            className="mt-3.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-md transition-all transform active:scale-95 flex items-center gap-1.5"
                          >
                            🎮 Main Game Sekarang
                          </button>
                        </div>
                      )}

                      {selectedMood === 'KENYANG' && (
                        <div>
                          <div className="flex items-center gap-2 text-emerald-500 mb-2 font-bold font-serif">
                            <Check size={18} className="border border-emerald-500 rounded-full" />
                            <span>Anak pinter kesayangan! 🍱💕</span>
                          </div>
                          <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                            Alhamdulillah, seneng banget dengernya kalau kamu udah makan kenyang! Jaga kesehatan selalu ya sayangku manisku. Jangan telat makan lagi biar pipi tembemmu tetep gemoy menggemaskan! Muachhh 😘🌸
                          </p>
                        </div>
                      )}

                      {selectedMood === 'SEBEL' && (
                        <div>
                          <div className="flex items-center gap-2 text-indigo-500 mb-2 font-bold font-serif">
                            <HeartOff className="animate-bounce" size={18} />
                            <span>Siapa yang berani bikin pacarku ngambek? 😤</span>
                          </div>
                          <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                            Ih kesel banget pasti ya beb? Sini aduin ke aku biar aku omelin dan jitak kepalanya haha! Tapi daripada cemberut terus bikin cantiknya berkurang, nanti sore aku beliin es krim atau cemilan manis kesukaanmu ya? Senyum dikit dong manisku... pipi cemberutnya mau aku cubit lho! 🥺🍦
                          </p>
                        </div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Footer Quote */}
                <p className="text-[11px] text-slate-400 font-medium italic mt-2">
                  "Website ini dibuat full dengan rasa cinta untuk menghiburmu kapanpun kamu mau."
                </p>
              </div>

            </motion.div>
          )}

          {/* TAB 2: GAME PANEL */}
          {activeTab === 'game' && (
            <motion.div
              key="tab-game"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="w-full"
            >
              <FallingHeartsGame 
                onScoreEarned={handleEarnPoints} 
                currentPoints={points} 
              />
            </motion.div>
          )}

          {/* TAB 3: COUPONS PANEL */}
          {activeTab === 'coupons' && (
            <motion.div
              key="tab-coupons"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="w-full"
            >
              <LoveWheel 
                coupons={config.coupons} 
                points={points} 
                onRedeem={handleRedeemCoupon} 
              />
            </motion.div>
          )}

          {/* TAB 4: AI COMPANION PENAL */}
          {activeTab === 'ai' && (
            <motion.div
              key="tab-ai"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="w-full"
            >
              <CompanionChat 
                boyfriendName={config.boyfriendName} 
                girlfriendName={config.girlfriendName} 
              />
            </motion.div>
          )}

          {/* TAB 5: MEMORY TIMELINE PANEL */}
          {activeTab === 'timeline' && (
            <motion.div
              key="tab-timeline"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="w-full"
            >
              <MemoryTimeline 
                memories={config.memories} 
                anniversaryDate={config.anniversaryDate} 
                girlfriendName={config.girlfriendName} 
              />
            </motion.div>
          )}

          {/* TAB 6: EDIT / CONFIGURATION SUITE */}
          {activeTab === 'edit' && (
            <motion.div
              key="tab-edit"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="w-full max-w-lg mx-auto bg-white/70 backdrop-blur-md rounded-3xl p-6 border border-pink-100 shadow-xl space-y-6"
            >
              <div>
                <h2 className="font-serif text-xl font-bold text-slate-800 flex items-center gap-2">
                  <Edit className="text-pink-500" size={20} />
                  Kustomisasi Website Cinta ⚙️
                </h2>
                <p className="text-[10px] text-slate-400 mt-0.5">Atur nama, tanggal jadian, dan kenangan kalian agar website ini jadi lebih personal!</p>
              </div>

              {/* Core Information Form */}
              <form onSubmit={handleUpdateConfig} className="space-y-4 text-left">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Nama Panggilanmu (Cowok)</label>
                    <input
                      type="text"
                      value={editBoyfriend}
                      onChange={(e) => setEditBoyfriend(e.target.value)}
                      placeholder="Ayang Ganteng"
                      className="w-full px-3 py-2 bg-white/80 border border-pink-100 rounded-xl text-xs focus:outline-none focus:border-pink-400"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Nama Pacar (Cewek)</label>
                    <input
                      type="text"
                      value={editGirlfriend}
                      onChange={(e) => setEditGirlfriend(e.target.value)}
                      placeholder="Cantiik"
                      className="w-full px-3 py-2 bg-white/80 border border-pink-100 rounded-xl text-xs focus:outline-none focus:border-pink-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Tanggal Jadian (Anniversary)</label>
                  <input
                    type="date"
                    value={editDate}
                    onChange={(e) => setEditDate(e.target.value)}
                    className="w-full px-3 py-2 bg-white/80 border border-pink-100 rounded-xl text-xs focus:outline-none focus:border-pink-400"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Pesan Utama (Surat Cinta Utama)</label>
                  <textarea
                    value={editLetter}
                    onChange={(e) => setEditLetter(e.target.value)}
                    rows={3}
                    placeholder="Tulis pesan penyemangat manis di beranda..."
                    className="w-full px-3 py-2 bg-white/80 border border-pink-100 rounded-xl text-xs focus:outline-none focus:border-pink-400"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-pink-500 hover:bg-pink-600 text-white font-bold text-xs rounded-xl shadow-md shadow-pink-100 transition-all transform active:scale-95"
                >
                  Simpan Perubahan Utama 💕
                </button>
              </form>

              {/* Add Memory Section */}
              <div className="border-t border-pink-50 pt-5">
                <h3 className="font-serif text-sm font-bold text-slate-700 flex items-center gap-1.5 mb-3">
                  <Plus size={14} className="text-pink-500" />
                  Tambah Cerita Kenangan Baru
                </h3>

                <form onSubmit={handleAddMemory} className="space-y-3.5 text-left">
                  <div className="grid grid-cols-3 gap-2.5">
                    <div className="col-span-2">
                      <label className="text-[9px] font-bold text-slate-400 uppercase">Tanggal</label>
                      <input
                        type="date"
                        value={newMemDate}
                        onChange={(e) => setNewMemDate(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-white/80 border border-pink-50 rounded-lg text-[11px] focus:outline-none focus:border-pink-400"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-bold text-slate-400 uppercase">Emoji</label>
                      <select
                        value={newMemEmoji}
                        onChange={(e) => setNewMemEmoji(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-white/80 border border-pink-50 rounded-lg text-[11px] focus:outline-none focus:border-pink-400"
                      >
                        <option value="💖">💖 Heart</option>
                        <option value="🍿">🍿 Movie</option>
                        <option value="🍲">🍲 Food</option>
                        <option value="🏖️">🏖️ Beach</option>
                        <option value="🎂">🎂 Birthday</option>
                        <option value="✨">✨ Magic</option>
                        <option value="💍">💍 Promise</option>
                        <option value="🧸">🧸 Teddy</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Judul Kenangan</label>
                    <input
                      type="text"
                      value={newMemTitle}
                      onChange={(e) => setNewMemTitle(e.target.value)}
                      placeholder="Contoh: Nemu Kafe Lucu Bareng ☕"
                      className="w-full px-2.5 py-1.5 bg-white/80 border border-pink-50 rounded-lg text-[11px] focus:outline-none focus:border-pink-400"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Cerita Singkat</label>
                    <textarea
                      value={newMemDesc}
                      onChange={(e) => setNewMemDesc(e.target.value)}
                      rows={2}
                      placeholder="Ceritakan momen seru tersebut..."
                      className="w-full px-2.5 py-1.5 bg-white/80 border border-pink-50 rounded-lg text-[11px] focus:outline-none focus:border-pink-400"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-[10px] uppercase tracking-wider rounded-lg transition-all transform active:scale-95"
                  >
                    Tambah Kenangan ✨
                  </button>
                </form>
              </div>

              {/* Delete Memories List */}
              {config.memories.length > 0 && (
                <div className="border-t border-pink-50 pt-5 text-left">
                  <h3 className="font-serif text-xs font-bold text-slate-600 mb-3">Daftar Kenangan & Hapus</h3>
                  <div className="max-h-40 overflow-y-auto space-y-2 pr-1.5 scrollbar-thin">
                    {config.memories.map((mem) => (
                      <div key={mem.id} className="p-2 bg-slate-50 border border-slate-100 rounded-xl flex justify-between items-center text-[11px]">
                        <span className="font-bold text-slate-700 truncate pr-3">{mem.emoji} {mem.title} ({mem.date})</span>
                        <button
                          onClick={() => handleDeleteMemory(mem.id)}
                          className="p-1 text-slate-400 hover:text-rose-500 rounded-lg transition-all"
                          title="Hapus kenangan"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Reset Application Back to default */}
              <div className="border-t border-pink-50 pt-5">
                <button
                  onClick={handleResetApp}
                  className="px-4 py-2 bg-slate-100 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 text-slate-500 hover:text-rose-600 font-bold text-[10px] uppercase rounded-xl transition-all"
                >
                  Reset Semua Data Cinta 🔄
                </button>
              </div>

            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* STUNNING FROSTED GLASS BOTTOM NAVIGATION MENU */}
      <nav className="fixed bottom-4 inset-x-0 mx-auto w-full max-w-lg px-4 md:px-0 z-40">
        <div className="bg-white/45 backdrop-blur-[28px] border border-white/75 shadow-[0_12px_40px_-8px_rgba(235,113,113,0.15)] rounded-2xl py-2 px-3 flex justify-around items-center">
          
          <button
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all flex-1 cursor-pointer ${
              activeTab === 'home' ? 'text-rose-500 scale-102 font-bold' : 'text-slate-500 hover:text-rose-400'
            }`}
          >
            <Home size={18} />
            <span className="text-[9px] mt-1">Beranda</span>
          </button>

          <button
            onClick={() => setActiveTab('game')}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all flex-1 cursor-pointer ${
              activeTab === 'game' ? 'text-rose-500 scale-102 font-bold' : 'text-slate-500 hover:text-rose-400'
            }`}
          >
            <Trophy size={18} />
            <span className="text-[9px] mt-1">Game</span>
          </button>

          <button
            onClick={() => setActiveTab('coupons')}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all flex-1 cursor-pointer ${
              activeTab === 'coupons' ? 'text-rose-500 scale-102 font-bold' : 'text-slate-500 hover:text-rose-400'
            }`}
          >
            <Ticket size={18} />
            <span className="text-[9px] mt-1">Kupon</span>
          </button>

          <button
            onClick={() => setActiveTab('ai')}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all flex-1 cursor-pointer ${
              activeTab === 'ai' ? 'text-rose-500 scale-102 font-bold' : 'text-slate-500 hover:text-rose-400'
            }`}
          >
            <Bot size={18} />
            <span className="text-[9px] mt-1">AI Gemoy</span>
          </button>

          <button
            onClick={() => setActiveTab('timeline')}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all flex-1 cursor-pointer ${
              activeTab === 'timeline' ? 'text-rose-500 scale-102 font-bold' : 'text-slate-500 hover:text-rose-400'
            }`}
          >
            <Calendar size={18} />
            <span className="text-[9px] mt-1">Kenangan</span>
          </button>

        </div>
      </nav>
    </div>
  );
}
