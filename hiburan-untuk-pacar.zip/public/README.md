Please upload your photo here as 'foto-kita.jpg'
