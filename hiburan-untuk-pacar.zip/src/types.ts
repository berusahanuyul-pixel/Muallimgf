export interface SweetConfig {
  boyfriendName: string;
  girlfriendName: string;
  anniversaryDate: string; // YYYY-MM-DD
  mainLoveLetter: string;
  coupons: LoveCoupon[];
  memories: MemoryItem[];
}

export interface LoveCoupon {
  id: string;
  title: string;
  description: string;
  emoji: string;
  redeemed: boolean;
  costPoints: number; // She gets points by playing "Catch My Love" game!
}

export interface MemoryItem {
  id: string;
  date: string;
  title: string;
  description: string;
  emoji: string;
}

export type ActiveTab = 'home' | 'game' | 'coupons' | 'ai' | 'timeline' | 'edit';
