import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Send, Heart, Bot, HelpCircle, AlertCircle, RefreshCw } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

interface CompanionChatProps {
  boyfriendName: string;
  girlfriendName: string;
}

const PRESET_QUERIES = [
  { text: "Beri aku gombalan maut terlucu! 🥺", label: "Gombalan Maut" },
  { text: "Aku lagi sedih/lelah, hibur dong... 😢", label: "Hibur Aku" },
  { text: "Tulis puisi cinta manis yang singkat! 📜", label: "Bikin Puisi" },
  { text: "Kenapa pacarku sayang banget sama aku ya? 🤔", label: "Alasan Sayang" }
];

export default function CompanionChat({ boyfriendName, girlfriendName }: CompanionChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize companion greeting
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          id: 'welcome',
          sender: 'assistant',
          text: `Halo cantiikkk! Aku **Asisten Gemoy** 🧸✨, perwakilan cinta dari pacar tersayangmu, **${boyfriendName}**!\n\n${boyfriendName} bilang ke aku kalau kamu harus selalu bahagia dan ceria. Kalau kamu lagi bosen, cape, atau pengen digombalin, langsung chat aku aja ya! Aku di sini 24 jam khusus buat nemenin kamu 💕`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, [boyfriendName, girlfriendName]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    try {
      const systemInstruction = `Anda adalah 'Asisten Gemoy', robot boneka beruang virtual yang super imut, bawel namun sangat perhatian. Anda ditugaskan oleh pacar sang pengguna bernama ${boyfriendName} untuk selalu menyayangi, menghibur, memberi pujian setinggi langit, dan mengasihi pengguna bernama ${girlfriendName}.
Akrablah dengan panggilan tuan putri, manisku, cantiik, pacar ceria, beb, atau sayang. Gunakan bahasa Indonesia kasual yang sangat menggemaskan, santun namun hiperaktif penuh energi cinta! Selalu tambahkan banyak emoji (🥺, 💖, 💞, 🥰, ✨, 🧸, 🌸, 🍬, 🐱) di setiap kalimat. Pastikan jawaban Anda terkesan sangat berempati jika dia menceritakan kelelahan atau kesedihannya, dan ingatkan dia betapa beruntung dan sayangnya ${boyfriendName} kepada dirinya.`;

      const response = await fetch('/api/gemini', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          prompt: `Sang pacar (${girlfriendName}) berkata: "${text}"`,
          systemInstruction: systemInstruction
        })
      });

      const data = await response.json();
      
      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: data.text || "Uh oh, hatiku lagi buntu rindu... Kirim ulang pesannya ya beb! 🥺",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (error) {
      const assistantErrorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: "Koneksi cinta kita lagi sedikit tersendat nih sayang... Pastikan koneksi internet aman dan pacarmu sudah pasang API key ya! Tapi tenang, cintanya pacarmu ke kamu gak akan pernah tersendat kok! 🥰💖",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, assistantErrorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: Date.now().toString(),
        sender: 'assistant',
        text: `Halo lagi kesayangan! **Asisten Gemoy** kembali segar dan siap menghiburmu lagi! Ada yang bisa aku bantu untuk menceriakan harimu? 🌸✨`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  return (
    <div className="w-full max-w-lg mx-auto bg-white/70 backdrop-blur-md rounded-3xl border border-pink-100 shadow-xl overflow-hidden flex flex-col h-[520px]">
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-500 via-rose-400 to-pink-500 px-5 py-4 flex justify-between items-center text-white">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center border border-white/30 animate-pulse">
            <Bot size={20} className="text-white fill-white/10" />
          </div>
          <div>
            <h3 className="font-bold text-sm leading-tight flex items-center gap-1">
              Asisten Gemoy 🧸
              <span className="w-2 h-2 bg-emerald-400 rounded-full inline-block animate-ping" />
            </h3>
            <p className="text-[10px] text-pink-100">Utusan cinta robot pendengar setiamu</p>
          </div>
        </div>
        <button
          onClick={handleClearChat}
          className="p-1.5 hover:bg-white/15 rounded-xl transition-all cursor-pointer text-pink-100 hover:text-white"
          title="Reset Percakapan"
        >
          <RefreshCw size={16} />
        </button>
      </div>

      {/* Messages Scrollbox */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-pink-50/20 to-white/10 scrollbar-thin">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className="max-w-[85%] flex items-start gap-1.5">
              {msg.sender === 'assistant' && (
                <div className="w-7 h-7 bg-pink-100 rounded-full flex items-center justify-center shrink-0 border border-pink-200 mt-1">
                  <Heart className="fill-pink-500 text-pink-500" size={12} />
                </div>
              )}
              
              <div className="flex flex-col">
                <div
                  className={`p-3 rounded-2xl text-xs leading-relaxed whitespace-pre-wrap shadow-sm ${
                    msg.sender === 'user'
                      ? 'bg-pink-500 text-white rounded-br-none font-semibold'
                      : 'bg-white text-slate-700 border border-pink-100 rounded-bl-none'
                  }`}
                >
                  {msg.text.split('**').map((part, index) => 
                    index % 2 === 1 ? <strong key={index} className="font-bold">{part}</strong> : part
                  )}
                </div>
                <span className="text-[9px] text-slate-400 mt-1 self-end px-1">{msg.timestamp}</span>
              </div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-start gap-1.5">
            <div className="w-7 h-7 bg-pink-100 rounded-full flex items-center justify-center shrink-0 border border-pink-200">
              <Sparkles className="text-pink-500 animate-spin" size={12} />
            </div>
            <div className="bg-white/80 border border-pink-100 p-3 rounded-2xl rounded-bl-none shadow-sm flex gap-1.5 items-center">
              <div className="w-1.5 h-1.5 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <div className="w-1.5 h-1.5 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <div className="w-1.5 h-1.5 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Preset Fast Chips */}
      <div className="px-4 py-2 bg-pink-50/30 border-t border-pink-100 flex gap-2 overflow-x-auto select-none no-scrollbar whitespace-nowrap">
        {PRESET_QUERIES.map((preset, index) => (
          <button
            key={index}
            onClick={() => handleSendMessage(preset.text)}
            disabled={isLoading}
            className="px-3 py-1.5 bg-white hover:bg-pink-50 border border-pink-100/70 text-slate-700 rounded-full text-[10px] font-bold shadow-xs hover:border-pink-300 transition-all shrink-0 cursor-pointer disabled:opacity-55 disabled:cursor-not-allowed"
          >
            {preset.label}
          </button>
        ))}
      </div>

      {/* Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(inputValue);
        }}
        className="p-3 border-t border-pink-100/70 bg-white flex gap-2 items-center"
      >
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          disabled={isLoading}
          placeholder="Ketik curhatanmu di sini ya cantiik..."
          className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs focus:bg-white focus:outline-none focus:border-pink-400 transition-all disabled:opacity-75"
        />
        <button
          type="submit"
          disabled={!inputValue.trim() || isLoading}
          className="p-2.5 bg-pink-500 hover:bg-pink-600 text-white rounded-xl shadow-md shadow-pink-100 transition-all transform active:scale-95 disabled:bg-slate-100 disabled:shadow-none disabled:text-slate-400 disabled:transform-none"
        >
          <Send size={16} />
        </button>
      </form>
    </div>
  );
}
