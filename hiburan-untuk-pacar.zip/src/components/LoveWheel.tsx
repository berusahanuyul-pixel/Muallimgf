import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Gift, Copy, Check, Ticket, Heart, Sparkles, AlertCircle } from 'lucide-react';
import { LoveCoupon } from '../types';

interface LoveWheelProps {
  coupons: LoveCoupon[];
  points: number;
  onRedeem: (couponId: string, cost: number) => void;
}

export default function LoveWheel({ coupons, points, onRedeem }: LoveWheelProps) {
  const [selectedCoupon, setSelectedCoupon] = useState<LoveCoupon | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'available' | 'my-coupons'>('available');

  const availableCoupons = coupons.filter(c => !c.redeemed);
  const myCoupons = coupons.filter(c => c.redeemed);

  const handleClaim = (coupon: LoveCoupon) => {
    if (points >= coupon.costPoints) {
      onRedeem(coupon.id, coupon.costPoints);
      setSelectedCoupon(coupon);
    }
  };

  const copyToClipboard = (coupon: LoveCoupon) => {
    const text = `Sayang... Aku mau klaim kupon cinta ini dong! 🥺💖\n\n🎟️ Kupon: [${coupon.emoji} ${coupon.title}]\n✨ Deskripsi: ${coupon.description}\n\nSegera direalisasikan ya beb! Muachhh 😘`;
    navigator.clipboard.writeText(text);
    setCopiedId(coupon.id);
    setTimeout(() => setCopiedId(null), 3000);
  };

  return (
    <div className="w-full max-w-lg mx-auto bg-white/70 backdrop-blur-md rounded-3xl p-6 border border-pink-100 shadow-xl relative">
      <div className="text-center mb-6">
        <h2 className="font-serif text-2xl font-bold text-pink-600 flex items-center justify-center gap-2">
          <Ticket className="text-pink-500 fill-pink-100" size={24} />
          Toko Kupon Cinta 🎟️
        </h2>
        <p className="text-xs text-slate-500 mt-1">Gunakan poin cintamu untuk membeli kupon kejutan khusus dari pacarmu!</p>
      </div>

      {/* Tabs */}
      <div className="flex bg-pink-50/50 p-1.5 rounded-2xl mb-6 border border-pink-100/50">
        <button
          onClick={() => setActiveTab('available')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'available'
              ? 'bg-gradient-to-r from-pink-500 to-rose-400 text-white shadow-md shadow-pink-100'
              : 'text-slate-600 hover:text-pink-500'
          }`}
        >
          Kupon Tersedia ({availableCoupons.length})
        </button>
        <button
          onClick={() => setActiveTab('my-coupons')}
          className={`flex-1 py-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'my-coupons'
              ? 'bg-gradient-to-r from-pink-500 to-rose-400 text-white shadow-md shadow-pink-100'
              : 'text-slate-600 hover:text-pink-500'
          }`}
        >
          Kupon Milikku 💕 ({myCoupons.length})
        </button>
      </div>

      {/* Current point display */}
      <div className="bg-pink-50/80 border border-pink-100 rounded-2xl p-3 mb-6 flex justify-between items-center">
        <span className="text-xs font-semibold text-slate-600 flex items-center gap-1">
          <Sparkles size={14} className="text-pink-400 animate-spin" />
          Tabungan Poin Cinta kamu:
        </span>
        <span className="text-sm font-extrabold text-pink-600 bg-white border border-pink-100 px-3 py-1 rounded-full shadow-inner">
          {points} POIN
        </span>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'available' ? (
          <motion.div
            key="available"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-3.5"
          >
            {availableCoupons.length === 0 ? (
              <div className="text-center py-10 px-4">
                <p className="text-sm text-slate-500">Wah, semua kupon sudah kamu borong! 🥳</p>
                <p className="text-[11px] text-pink-500 mt-1 font-semibold">Tunggu pacarmu menambahkan kupon baru ya!</p>
              </div>
            ) : (
              availableCoupons.map(coupon => {
                const canAfford = points >= coupon.costPoints;
                return (
                  <motion.div
                    key={coupon.id}
                    layoutId={coupon.id}
                    className="p-4 bg-white/95 rounded-2xl border border-pink-100 flex items-center justify-between shadow-sm hover:shadow-md transition-all relative overflow-hidden group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-pink-100/50 rounded-2xl flex items-center justify-center text-2xl shadow-inner shrink-0 group-hover:scale-110 transition-transform">
                        {coupon.emoji}
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                          {coupon.title}
                        </h3>
                        <p className="text-xs text-slate-500 mt-0.5 pr-2 leading-relaxed">{coupon.description}</p>
                      </div>
                    </div>

                    <div className="flex flex-col items-end shrink-0 gap-1.5 pl-2 border-l border-pink-50">
                      <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">{coupon.costPoints} POIN</span>
                      <button
                        onClick={() => handleClaim(coupon)}
                        disabled={!canAfford}
                        className={`px-3 py-1.5 rounded-xl font-bold text-[10px] uppercase transition-all transform active:scale-95 ${
                          canAfford
                            ? 'bg-pink-500 hover:bg-pink-600 text-white shadow-md shadow-pink-150 cursor-pointer'
                            : 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                        }`}
                      >
                        Beli Kupon
                      </button>
                    </div>
                  </motion.div>
                );
              })
            )}
          </motion.div>
        ) : (
          <motion.div
            key="my-coupons"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-3.5"
          >
            {myCoupons.length === 0 ? (
              <div className="text-center py-10 px-4">
                <div className="w-14 h-14 bg-pink-50 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Ticket className="text-pink-300" size={24} />
                </div>
                <p className="text-sm text-slate-500">Belum ada kupon yang dibeli nih.</p>
                <p className="text-[11px] text-slate-400 mt-1">Main game dulu dan kumpulkan poin cinta ya sayang! 💕</p>
              </div>
            ) : (
              myCoupons.map(coupon => (
                <motion.div
                  key={coupon.id}
                  className="p-4 bg-gradient-to-r from-rose-50 to-pink-50 rounded-2xl border-2 border-dashed border-pink-200 flex items-center justify-between shadow-sm relative overflow-hidden"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-white/90 rounded-2xl flex items-center justify-center text-2xl shadow-sm shrink-0">
                      {coupon.emoji}
                    </div>
                    <div>
                      <h3 className="font-serif font-bold text-slate-800 text-sm flex items-center gap-1">
                        {coupon.title}
                        <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-sans uppercase font-bold tracking-wide">Milikku</span>
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5 pr-2 leading-relaxed">{coupon.description}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => copyToClipboard(coupon)}
                    className="p-2.5 bg-white hover:bg-pink-50 text-pink-500 hover:text-pink-600 rounded-xl shadow-sm border border-pink-100 shrink-0 transition-all transform active:scale-95"
                    title="Klaim lewat WhatsApp"
                  >
                    {copiedId === coupon.id ? (
                      <Check size={16} className="text-emerald-500" />
                    ) : (
                      <div className="flex items-center gap-1 text-[10px] font-bold text-pink-600">
                        <Copy size={12} />
                        <span>KLAIM</span>
                      </div>
                    )}
                  </button>
                </motion.div>
              ))
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Gift Unlocked Modal Dialog */}
      <AnimatePresence>
        {selectedCoupon && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white rounded-3xl p-6 max-w-sm w-full text-center border border-pink-100 relative shadow-2xl overflow-hidden"
            >
              {/* Confetti effect inside standard graphics */}
              <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-pink-400 via-rose-500 to-amber-400" />
              
              <div className="w-16 h-16 bg-pink-100/80 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                <Gift className="text-pink-600" size={32} />
              </div>

              <h3 className="font-serif text-xl font-bold text-slate-800 mb-1">Berhasil Membeli Kupon!</h3>
              <p className="text-xs text-rose-500 font-semibold mb-4 flex items-center justify-center gap-1">
                <Heart size={12} className="fill-rose-500 animate-pulse" />
                Kupon baru ditambahkan ke koleksimu!
              </p>

              <div className="bg-pink-50/50 border border-pink-100 rounded-2xl p-4 mb-5 text-left">
                <div className="flex gap-2.5 items-center mb-1.5">
                  <span className="text-2xl">{selectedCoupon.emoji}</span>
                  <span className="font-extrabold text-slate-800 text-sm">{selectedCoupon.title}</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{selectedCoupon.description}</p>
              </div>

              <div className="text-[10px] text-slate-400 mb-5 flex items-center justify-center gap-1 bg-slate-50 py-1.5 px-3 rounded-full">
                <AlertCircle size={12} />
                <span>Klik Klaim di tab 'Kupon Milikku' untuk chat pacarmu!</span>
              </div>

              <div className="flex gap-2.5">
                <button
                  onClick={() => {
                    setSelectedCoupon(null);
                    setActiveTab('my-coupons');
                  }}
                  className="flex-1 py-2.5 bg-pink-500 hover:bg-pink-600 text-white rounded-xl font-bold text-xs shadow-md shadow-pink-100 transition-all"
                >
                  Buka Koleksiku
                </button>
                <button
                  onClick={() => setSelectedCoupon(null)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold text-xs transition-all"
                >
                  Tutup
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
