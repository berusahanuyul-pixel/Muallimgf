import React from 'react';
import { motion } from 'motion/react';
import { Calendar, Heart, Shield, Sparkles } from 'lucide-react';
import { MemoryItem } from '../types';

interface MemoryTimelineProps {
  memories: MemoryItem[];
  anniversaryDate: string;
  girlfriendName: string;
}

export default function MemoryTimeline({ memories, anniversaryDate, girlfriendName }: MemoryTimelineProps) {
  // Calculate total days together
  const calculateDaysTogether = () => {
    try {
      const anniversary = new Date(anniversaryDate);
      const today = new Date();
      // Reset hours to compare exactly by day
      anniversary.setHours(0, 0, 0, 0);
      today.setHours(0, 0, 0, 0);
      const diffTime = Math.abs(today.getTime() - anniversary.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    } catch (e) {
      return 1;
    }
  };

  const daysCounter = calculateDaysTogether();
  const sortedMemories = [...memories].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="w-full max-w-lg mx-auto bg-white/70 backdrop-blur-md rounded-3xl p-6 border border-pink-100 shadow-xl relative">
      {/* Dynamic Day Counter Card */}
      <div className="bg-gradient-to-br from-pink-500 to-rose-400 text-white rounded-2xl p-5 mb-8 text-center relative overflow-hidden shadow-lg shadow-pink-100">
        <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full blur-xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-20 h-20 bg-rose-300/10 rounded-full blur-lg pointer-events-none" />
        
        <Sparkles className="mx-auto mb-2 text-amber-200 animate-pulse" size={24} />
        <h3 className="font-semibold text-xs uppercase tracking-widest text-pink-100">Perjalanan Cinta Kita</h3>
        
        <div className="my-2.5 flex items-center justify-center gap-1">
          <span className="font-serif text-4xl font-extrabold tracking-tight tabular-nums animate-bounce-slow">
            {daysCounter}
          </span>
          <span className="text-xl font-bold font-serif">Hari</span>
        </div>
        
        <p className="text-[11px] leading-relaxed text-pink-50/90 max-w-xs mx-auto">
          Mengarungi waktu demi waktu, membuat kenangan indah bersama <strong>{girlfriendName}</strong> tercinta. Semoga selamanya ya sayang! 💖
        </p>
      </div>

      <div className="mb-5">
        <h2 className="font-serif text-xl font-bold text-slate-800 flex items-center gap-2">
          <Calendar className="text-pink-500" size={20} />
          Garis Waktu Kenangan Indah ✨
        </h2>
        <p className="text-[10px] text-slate-500 mt-1">Momentum bersejarah dan kenangan termanis yang tak pernah terlupakan.</p>
      </div>

      {/* The Timeline Elements */}
      {sortedMemories.length === 0 ? (
        <div className="text-center py-8 text-slate-500 text-xs">
          Belum ada cerita sejarah cinta yang ditambahkan nih... 
          <p className="mt-1 text-[10px] text-pink-500 font-semibold">Tulis kenangan pertamamu di pengaturan ya sayang!</p>
        </div>
      ) : (
        <div className="relative border-l border-pink-200 pl-4 ml-2.5 py-2 space-y-6">
          {sortedMemories.map((memory, index) => (
            <motion.div
              key={memory.id}
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative"
            >
              {/* Floating dot connector */}
              <div className="absolute -left-[24.5px] top-1.5 w-4 h-4 bg-white border-2 border-pink-400 rounded-full flex items-center justify-center shadow-xs">
                <div className="w-1.5 h-1.5 bg-pink-500 rounded-full" />
              </div>

              {/* Memory Card */}
              <div className="bg-white/95 border border-pink-100/70 rounded-2xl p-4 shadow-xs relative overflow-hidden group hover:shadow-md hover:border-pink-200 transition-all">
                <div className="absolute top-3 right-4 text-xl">
                  {memory.emoji || "💖"}
                </div>
                
                <span className="text-[10px] font-extrabold text-pink-500 uppercase tracking-wider block mb-1">
                  {new Date(memory.date).toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })}
                </span>
                
                <h3 className="font-extrabold text-sm text-slate-800">
                  {memory.title}
                </h3>
                
                <p className="text-xs text-slate-600 mt-1.5 leading-relaxed whitespace-pre-wrap">
                  {memory.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
