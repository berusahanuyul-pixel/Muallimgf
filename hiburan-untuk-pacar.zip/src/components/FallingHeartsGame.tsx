import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Sparkles, Trophy, Play, Info, RotateCcw } from 'lucide-react';

interface HeartItem {
  id: number;
  x: number; // percentage (0 - 100)
  y: number; // percentage (top to bottom)
  speed: number;
  word: string;
  points: number;
  scale: number;
}

const SWEET_WORDS = [
  "Sayang", "Love You", "Kangen 🥺", "Cantiik 🌸", "Semangat ✨", 
  "Gemes 🥰", "Miss You", "Muuach 💋", "Peluk 🤗", "Beli Boba 🧋",
  "Nasi Goreng 🍲", "Sehat Selalu 🧸", "Masa Depan 💍", "My Queen 👑"
];

interface FallingHeartsGameProps {
  onScoreEarned: (points: number) => void;
  currentPoints: number;
}

export default function FallingHeartsGame({ onScoreEarned, currentPoints }: FallingHeartsGameProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [basketX, setBasketX] = useState(50); // percentage (0 - 100)
  const [hearts, setHearts] = useState<HeartItem[]>([]);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [capturedWord, setCapturedWord] = useState<string | null>(null);
  const [showTutorial, setShowTutorial] = useState(true);

  const gameAreaRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Play a procedurally generated sweet sound
  const playSound = (freq: number, type: 'sine' | 'triangle' | 'sawtooth') => {
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } catch (e) {
      // Audio context might be blocked or unsupported
    }
  };

  // Handle key listeners for computer
  useEffect(() => {
    if (!isPlaying) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        setBasketX(prev => Math.max(5, prev - 8));
      } else if (e.key === 'ArrowRight') {
        setBasketX(prev => Math.min(95, prev + 8));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying]);

  // Handle mouse movement over the game element
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isPlaying || !gameAreaRef.current) return;
    const rect = gameAreaRef.current.getBoundingClientRect();
    const relativeX = ((e.clientX - rect.left) / rect.width) * 100;
    setBasketX(Math.max(5, Math.min(95, relativeX)));
  };

  // Touch listener for phones
  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isPlaying || !gameAreaRef.current) return;
    const rect = gameAreaRef.current.getBoundingClientRect();
    const touch = e.touches[0];
    const relativeX = ((touch.clientX - rect.left) / rect.width) * 100;
    setBasketX(Math.max(5, Math.min(95, relativeX)));
  };

  // Start the game loop
  useEffect(() => {
    if (!isPlaying) return;

    // Reset game state
    setScore(0);
    setTimeLeft(30);
    setHearts([]);

    // Timer tick
    const timerInterval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setIsPlaying(false);
          onScoreEarned(score);
          playSound(440, 'triangle'); // high clear chime at game end
          setTimeout(() => playSound(554, 'triangle'), 100);
          setTimeout(() => playSound(659, 'triangle'), 200);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // Heart spawner
    const spawnInterval = setInterval(() => {
      const isGold = Math.random() < 0.15; // 15% chance to spawn gold heart
      const newHeart: HeartItem = {
        id: Date.now() + Math.random(),
        x: 10 + Math.random() * 80,
        y: -10,
        speed: 1.5 + Math.random() * 2.5,
        word: SWEET_WORDS[Math.floor(Math.random() * SWEET_WORDS.length)],
        points: isGold ? 20 : 10,
        scale: isGold ? 1.3 : 1.0,
      };
      setHearts(prev => [...prev, newHeart]);
    }, 900);

    // Heart mechanics loop
    const physicsInterval = setInterval(() => {
      setHearts(prevHearts => {
        const remaining: HeartItem[] = [];
        
        prevHearts.forEach(heart => {
          const nextY = heart.y + heart.speed;
          
          // Check collision with basket (bottom of the screen around y = 85 to 93)
          const basketCollisionDistanceY = Math.abs(nextY - 88); 
          const basketCollisionDistanceX = Math.abs(heart.x - basketX);

          if (basketCollisionDistanceY < 5 && basketCollisionDistanceX < 12) {
            // Heart caught!
            setScore(prev => prev + heart.points);
            setCapturedWord(heart.word);
            playSound(heart.points === 20 ? 659 : 523, 'sine'); // cute sound
            
            // clear feedback text after some ms
            setTimeout(() => {
              setCapturedWord(current => current === heart.word ? null : current);
            }, 800);
          } else if (nextY < 100) {
            remaining.push({ ...heart, y: nextY });
          }
        });
        
        return remaining;
      });
    }, 40);

    return () => {
      clearInterval(timerInterval);
      clearInterval(spawnInterval);
      clearInterval(physicsInterval);
    };
  }, [isPlaying, basketX]);

  const startGame = () => {
    // Resume context optionally
    if (typeof window !== 'undefined') {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    setIsPlaying(true);
    setShowTutorial(false);
    playSound(415, 'sine');
    setTimeout(() => playSound(523, 'sine'), 100);
    setTimeout(() => playSound(659, 'sine'), 200);
  };

  return (
    <div className="w-full max-w-lg mx-auto bg-white/70 backdrop-blur-md rounded-3xl p-6 border border-pink-100 shadow-xl overflow-hidden relative">
      <div className="flex flex-wrap justify-between items-center mb-4 gap-2">
        <div>
          <h2 className="font-serif text-2xl font-bold text-pink-600 flex items-center gap-2">
            <Heart className="fill-pink-500 text-pink-500 animate-pulse" size={24} />
            Tangkap Kasih Sayang
          </h2>
          <p className="text-xs text-slate-500">Kumpulkan poin cinta untuk ditukar dengan kupon kejutan!</p>
        </div>
        <div className="bg-pink-100/80 px-3 py-1.5 rounded-full flex items-center gap-2 text-pink-700 font-bold text-sm">
          <Trophy size={16} className="text-pink-500" />
          <span>{currentPoints} Poin</span>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!isPlaying ? (
          <motion.div
            key="start-screen"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex flex-col items-center justify-center py-10 px-4 text-center"
          >
            <div className="w-24 h-24 bg-pink-100 rounded-full flex items-center justify-center mb-4 shadow-inner">
              <Heart className="fill-pink-500 text-pink-500 w-12 h-12 animate-bounce" />
            </div>

            <h3 className="font-serif text-xl font-bold text-slate-800 mb-2">Game Tangkap Cinta</h3>
            <p className="text-sm text-slate-600 max-w-sm mb-6">
              Gerakkan mangkok cinta ke kiri dan kanan untuk menangkap hati yang jatuh. 
              Dapatkan poin cinta sebanyak-banyaknya dalam 30 detik!
            </p>

            {showTutorial && (
              <div className="bg-pink-50/80 border border-pink-200/50 rounded-2xl p-3 mb-6 text-xs text-pink-700 flex gap-2 items-start text-left max-w-sm">
                <Info size={16} className="shrink-0 mt-0.5 text-pink-500" />
                <div>
                  <span className="font-semibold">Cara Bermain:</span> Geser jari/kursor mouse di area game, atau gunakan tombol <kbd className="bg-white px-1 border rounded shadow-sm text-pink-600 font-bold">&#8592;</kbd> dan <kbd className="bg-white px-1 border rounded shadow-sm text-pink-600 font-bold">&#8594;</kbd> di keyboard kamu!
                </div>
              </div>
            )}

            <button
              onClick={startGame}
              className="px-6 py-3 bg-pink-500 hover:bg-pink-600 text-white rounded-full font-bold shadow-lg shadow-pink-200 hover:shadow-pink-300 transition-all flex items-center gap-2 transform active:scale-95 text-sm"
            >
              <Play size={16} fill="currentColor" />
              Mulai Bermain!
            </button>
          </motion.div>
        ) : (
          <motion.div
            key="game-screen"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="relative"
          >
            {/* HUD / Stats */}
            <div className="flex justify-between items-center text-sm font-semibold text-slate-700 mb-2 px-2">
              <div className="text-pink-600">Skor Game: <span className="text-lg font-extrabold">{score}</span></div>
              <div className="bg-amber-100 text-amber-800 px-2.5 py-0.5 rounded-full text-xs">
                Sisa: <span className="font-bold">{timeLeft}s</span>
              </div>
            </div>

            {/* Game Playing Canvas-Like Area */}
            <div
              ref={gameAreaRef}
              onMouseMove={handleMouseMove}
              onTouchMove={handleTouchMove}
              className="w-full h-80 bg-gradient-to-b from-pink-50/50 via-rose-50/20 to-pink-50/60 rounded-2xl border border-pink-100 relative overflow-hidden cursor-crosshair select-none"
            >
              {/* Captured word popup */}
              <AnimatePresence>
                {capturedWord && (
                  <motion.div
                    initial={{ scale: 0.5, opacity: 0, y: 15 }}
                    animate={{ scale: 1.2, opacity: 1, y: 0 }}
                    exit={{ scale: 0.8, opacity: 0 }}
                    className="absolute top-20 left-0 right-0 mx-auto text-center pointer-events-none z-10 font-bold font-serif text-rose-500 flex items-center justify-center gap-1.5"
                  >
                    <Sparkles size={16} className="text-amber-400 animate-spin" />
                    <span className="bg-white/90 border border-pink-200 shadow-sm px-3 py-1 rounded-full text-sm">
                      {capturedWord}
                    </span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Falling Hearts */}
              {hearts.map(heart => (
                <div
                  key={heart.id}
                  style={{
                    left: `${heart.x}%`,
                    top: `${heart.y}%`,
                    transform: `translate(-50%, -50%) scale(${heart.scale})`,
                  }}
                  className={`absolute pointer-events-none transition-all duration-75 flex flex-col items-center justify-center`}
                >
                  <Heart
                    className={`${heart.points === 20 ? 'fill-amber-400 text-amber-500 animate-spin-slow' : 'fill-pink-500 text-pink-500'} drop-shadow-md`}
                    size={24}
                  />
                  {heart.points === 20 && (
                    <span className="absolute -top-3 text-[9px] font-bold text-amber-600 uppercase bg-amber-100 rounded px-1 scale-90 border border-amber-300">
                      Bonus!
                    </span>
                  )}
                </div>
              ))}

              {/* Basket Catcher */}
              <div
                style={{
                  left: `${basketX}%`,
                  bottom: '5%',
                }}
                className="absolute -translate-x-1/2 flex flex-col items-center transition-all duration-75"
              >
                {/* Cute bowl or cloud design */}
                <div className="relative flex items-center justify-center">
                  <div className="w-20 h-8 bg-gradient-to-r from-pink-500 to-rose-400 rounded-b-3xl rounded-t-xl shadow-lg border-2 border-white flex items-center justify-center">
                    <span className="text-[10px] font-extrabold text-white tracking-widest uppercase">LOVE</span>
                  </div>
                  <div className="absolute -top-3 flex gap-2">
                    <Heart className="fill-white text-white opacity-80" size={12} />
                    <Heart className="fill-white text-white animate-bounce" size={14} />
                    <Heart className="fill-white text-white opacity-80" size={12} />
                  </div>
                </div>
              </div>
            </div>

            {/* Hint for touch devices */}
            <p className="text-center text-[10px] text-slate-400 mt-2">
              Seret jari atau mouse di atas kotak di atas untuk menangkap hati!
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
